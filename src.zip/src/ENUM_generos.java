
public enum ENUM_generos {
	ACAO, AVENTURA, COMEDIA, DRAMA, SUSPENSE, TERROR;
	
}
